$$jv:inc:pages/mapping.js$$
//jv.regModVer('js/utils.js', '{{getCurCacheVer("js/utils.js", curTag)}}');